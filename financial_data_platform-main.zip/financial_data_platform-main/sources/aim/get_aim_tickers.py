import requests
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

def get_tickers_from_stockanalysis():
    """Get UK AIM tickers from stockanalysis.com"""
    url = "https://stockanalysis.com/list/london-stock-exchange/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    print(f"Trying stockanalysis.com...")
    r = requests.get(url, headers=headers, timeout=15)
    print(f"Status: {r.status_code}, Size: {len(r.content)} bytes")
    if "No data" not in r.text and r.status_code == 200:
        print(r.text[:500])

def get_tickers_from_hl():
    """Get AIM tickers from Hargreaves Lansdown"""
    url = "https://www.hl.co.uk/shares/stock-market-summary/aim"
    headers = {"User-Agent": "Mozilla/5.0"}
    print(f"\nTrying Hargreaves Lansdown...")
    r = requests.get(url, headers=headers, timeout=15)
    print(f"Status: {r.status_code}, Size: {len(r.content)} bytes")

def get_tickers_from_lse_search():
    """Use LSE search API"""
    url = "https://api.londonstockexchange.com/api/gw/lse/instruments/alldata/aimed"
    params = {"numberOfResults": 50, "startPage": 1}
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json",
        "Referer": "https://www.londonstockexchange.com"
    }
    print(f"\nTrying LSE API with referer...")
    r = requests.get(url, params=params, headers=headers, timeout=15)
    print(f"Status: {r.status_code}")
    if r.status_code == 200:
        print(r.text[:1000])

if __name__ == "__main__":
    get_tickers_from_stockanalysis()
    get_tickers_from_hl()
    get_tickers_from_lse_search()
