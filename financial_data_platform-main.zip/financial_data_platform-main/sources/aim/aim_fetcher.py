import yfinance as yf
import sys
import os
import time
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), '..', '..', 'config', '.env'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from sources.database import get_session, Stock
from sources.aim.aim_tickers import AIM_TICKERS

def fetch_stock_data(ticker):
    try:
        info = yf.Ticker(ticker).info
        price = info.get("regularMarketPrice") or info.get("currentPrice")
        name = info.get("longName") or info.get("shortName", "")
        if not price or not name:
            return None
        return {
            "ticker": ticker,
            "company_name": name,
            "exchange": info.get("exchange", "LSE"),
            "country": "United Kingdom",
            "sector": info.get("sector", ""),
            "currency": info.get("currency", "GBP"),
            "market_cap_usd": info.get("marketCap"),
            "price": price,
            "pe_ratio": info.get("trailingPE"),
            "pb_ratio": info.get("priceToBook"),
            "dividend_yield": info.get("dividendYield"),
            "week_52_high": info.get("fiftyTwoWeekHigh"),
            "week_52_low": info.get("fiftyTwoWeekLow"),
            "revenue_growth": info.get("revenueGrowth"),
            "debt_to_equity": info.get("debtToEquity"),
            "market": "UK_AIM"
        }
    except Exception:
        return None

def save_stock(session, data):
    try:
        existing = session.query(Stock).filter_by(ticker=data["ticker"]).first()
        if existing:
            for key, value in data.items():
                setattr(existing, key, value)
        else:
            session.add(Stock(**data))
        session.commit()
        return True
    except Exception:
        session.rollback()
        return False

def run_aim_ingestion():
    session = get_session()
    saved = 0

    print(f"Starting UK AIM ingestion — {len(AIM_TICKERS)} tickers\n")

    for i, ticker in enumerate(AIM_TICKERS):
        data = fetch_stock_data(ticker)
        if data and save_stock(session, data):
            saved += 1
            print(f"[{i+1}/{len(AIM_TICKERS)}] Saved: {data['company_name']} ({ticker})")
        if i % 20 == 0 and i > 0:
            time.sleep(2)

    session.close()

    final = get_session()
    total = final.query(Stock).filter_by(market="UK_AIM").count()
    final.close()

    print(f"\nDone — {saved} saved this run, {total} total in database")

if __name__ == "__main__":
    run_aim_ingestion()
