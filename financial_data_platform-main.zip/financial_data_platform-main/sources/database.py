from sqlalchemy import create_engine, Column, String, Float, DateTime, Integer
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.sql import func
from dotenv import load_dotenv
import os

load_dotenv(os.path.join(os.path.dirname(__file__), '..', 'config', '.env'))

DATABASE_URL = os.getenv("DATABASE_URL")
Base = declarative_base()

class Stock(Base):
    __tablename__ = "stocks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    ticker = Column(String(20), unique=True, nullable=False)
    company_name = Column(String(255))
    exchange = Column(String(50))
    country = Column(String(100))
    sector = Column(String(100))
    currency = Column(String(10))
    market_cap_usd = Column(Float)
    price = Column(Float)
    pe_ratio = Column(Float)
    pb_ratio = Column(Float)
    dividend_yield = Column(Float)
    week_52_high = Column(Float)
    week_52_low = Column(Float)
    revenue_growth = Column(Float)
    debt_to_equity = Column(Float)
    market = Column(String(50))
    last_updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

class EconomicIndicator(Base):
    __tablename__ = "economic_indicators"

    id = Column(Integer, primary_key=True, autoincrement=True)
    country = Column(String(100), nullable=False)
    country_code = Column(String(10))
    indicator_name = Column(String(255), nullable=False)
    indicator_code = Column(String(100))
    value = Column(Float)
    unit = Column(String(100))
    period = Column(String(20))
    source = Column(String(100))
    last_updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

def get_engine():
    return create_engine(DATABASE_URL)

def get_session():
    engine = get_engine()
    Session = sessionmaker(bind=engine)
    return Session()

def create_tables():
    engine = get_engine()
    Base.metadata.create_all(engine)
    print("✅ Financial database tables created")

if __name__ == "__main__":
    create_tables()